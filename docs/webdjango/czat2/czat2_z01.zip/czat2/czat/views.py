from django.shortcuts import render


def index(request):
    """Strona główna aplikacji."""
    return render(request, 'czat/index.html')
